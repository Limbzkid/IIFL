/*$(document).ready(function() {

    $('#datepicker-example1').Zebra_DatePicker({
      //format: 'd-m-Y',
      //direction: ['2012-08-01', '2016-10-12']
    });
    $('#datepicker-example2').Zebra_DatePicker({
     // format: 'd-m-Y',
      //direction: ['05-10-2016', true]
      //maxDate: '-25Y'
      //direction: ['1990-01-01', true]
      yearRange: '1972:2011'
    });

 });*/