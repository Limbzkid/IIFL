<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>IIFL</title>
	<link href="css/fonts.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="js/jquery.2.1.4.min.js"></script>
	<script type="text/javascript" src="js/common.js"></script>
</head>
<body>
	<div id="main-wrap">
			<header>
				<div class="header-inner">
					<div class="logo"><img src="images/logo.jpg" class="scale"></div>
					<div class="personal-loan"><img src="images/personal.png" class="scale"></div>
					<div class="clr"></div>
					<div class="continue-journey-link"><a href="continue-your-journey.php">Resume your previously saved form</a></div>
					<div class="card-container-outerhome">
						<div class="pendulamline-home"><img src="images/pendulamline.jpg" class="scale"></div>
						<div class="card-container1 effect__random" data-id="1">
							<div class="card__front">
								<img src="images/48hours.png" class="scale">
								<div class="express-home">Express<br>Personal<br>Loan</div>
							</div>
							<div class="card__back">
								<img src="images/48hours.png" class="scale">
								<p class="pendulamtxt">DISBURSAL<br> IN<br> 8 HOURS* <br/><small> T&C Apply</small></p>
							</div>
						</div>
					</div>
				</div>
			</header>

	</div>

<script src="js/cards.js" type="text/javascript"></script>
</body>
</html>