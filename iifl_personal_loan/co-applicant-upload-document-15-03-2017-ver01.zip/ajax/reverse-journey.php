<?php session_start(); ?>
<?php require_once("../includes/functions.php"); ?>
<?php
	$crmLeadIdType 	= xss_filter($_POST['crmLeadIDType']);
	$crmLeadId 		= xss_filter($_POST['crmLeadID']);
	if($crmLeadIdType) {
		if($crmLeadIdType == 'OTP') {
			if(alphanumerix($crmLeadId)) {
				$otpUrl = COMMON_API.'BreakJourneyOTP';
				$curl_post_data = array(
					'CRMLeadID' => $crmLeadId
				);
				$headers = array (
					"Content-Type: application/json"
				);
				$encodeddata = json_encode($curl_post_data);
				$handle = curl_init(); 
				curl_setopt($handle, CURLOPT_URL, $otpUrl);
				curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
				curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($handle, CURLOPT_POST, true);
				curl_setopt($handle, CURLOPT_POSTFIELDS, $encodeddata);
				$curl_response = curl_exec($handle);
				$json = json_decode($curl_response);
				curl_close($handle);
				
				if($json->Status == 'Y')  {
					$_SESSION['resume_applicant']['otp'] = $json->OTP;
					$_SESSION['personal_details']['CRMLeadID'] = $_SESSION['resume_applicant']['CRMLeadID'] = $json->CRMLeadId;
					$_SESSION['personal_details']['mobileno'] = $_SESSION['resume_applicant']['MobileNumber'] = $json->MobileNumber;
				}
				echo $curl_response; exit();
			} else {
				echo 0;
			}
		} else {
			if(alphanumerix($crmLeadId)) {
				$OTP = xss_filter($_POST['OTP']);
				$otpUrl = COMMON_API.'BreakJourneyVerifyOTP_indigo';
				$curl_post_data = array(
					'CRMLeadID' => $crmLeadId,
					'OTP' 		=> $OTP
				);
				$headers = array (
					"Content-Type: application/json"
				);
			
				$encodeddata = json_encode($curl_post_data);
				$handle = curl_init(); 
				curl_setopt($handle, CURLOPT_URL, $otpUrl);
				curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
				curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($handle, CURLOPT_POST, true);
				curl_setopt($handle, CURLOPT_POSTFIELDS, $encodeddata);
				$curl_response = curl_exec($handle);
				curl_close($handle);
				$jsonDecode 	= json_decode($curl_response);
				//echo "<pre>"; print_r($jsonDecode); echo '</pre>'; exit;
				$requestJson 	= json_decode($jsonDecode->RequestJson);
				$responseJson 	= json_decode($jsonDecode->ResponseJson);
				//echo "<pre>"; print_r($curl_response); echo "</pre>";  exit;
				if($jsonDecode->Status == 'Y') {
					if(isset($responseJson->PermanentPin) && isset($responseJson->CurrentPin)) {
						$service_url = COMMON_API. 'GetDetailByPincode';
						$curl = curl_init($service_url);
						$curl_post_data = array(
							'CRMLeadID'	=> xss_filter($responseJson->CRMLeadID),
							'Pincode' 	=> xss_filter($responseJson->PermanentPin)
						);

						$headers = array (
							"Content-Type: application/json"
						);
					
						$decodeddata = json_encode($curl_post_data);
						$handle = curl_init(); 
						curl_setopt($handle, CURLOPT_URL, $service_url);
						curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
						curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($handle, CURLOPT_POST, true);
						curl_setopt($handle, CURLOPT_POSTFIELDS, $decodeddata);
						$curl_response = curl_exec($handle);
						curl_close($handle);
						
						$decoded = json_decode($curl_response);
						$_SESSION['personal_details']['permanentpincode'] 	= xss_filter($responseJson->PermanentPin);
						$_SESSION['personal_details']['perm_city_code'] 	= $decoded->CityCode;
						$_SESSION['personal_details']['perm_state_code'] 	= $decoded->StateCode;
						$permanentCity = $_SESSION['personal_details']['permanentcity']	= $decoded->City;
						$permanentState = $_SESSION['personal_details']['permanentstate'] 	= $decoded->State;

						$service_url = COMMON_API. 'GetDetailByPincode';
						$curl = curl_init($service_url);
						$curl_post_data = array(
							'CRMLeadID'	=> xss_filter($responseJson->CRMLeadID),
							'Pincode' 	=> xss_filter($responseJson->CurrentPin)
						);
						$headers = array (
							"Content-Type: application/json"
						);
						$decodeddata = json_encode($curl_post_data);
						$handle = curl_init(); 
						curl_setopt($handle, CURLOPT_URL, $service_url);
						curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
						curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
						curl_setopt($handle, CURLOPT_POST, true);
						curl_setopt($handle, CURLOPT_POSTFIELDS, $decodeddata);
						$curl_response = curl_exec($handle);
						curl_close($handle);
						
						$decoded = json_decode($curl_response);
						$_SESSION['personal_details']['currentpincode'] 	= xss_filter($responseJson->CurrentPin);
						$_SESSION['personal_details']['curr_city_code'] 	= $decoded->CityCode;
						$_SESSION['personal_details']['curr_state_code'] 	= $decoded->StateCode;
						$currentCity = $_SESSION['personal_details']['currentcity'] 		= $decoded->City;
						$currentState = $_SESSION['personal_details']['currentstate'] 		= $decoded->State;
					}
					if($jsonDecode->PageNumber == '1') {
						if($responseJson->Status == 'Success') {
							$obligation 						= xss_filter($requestJson[0]->MonthlyObligation);
							$salary 								= xss_filter($requestJson[0]->MonthlySalary);
							$max_tenure 						= xss_filter($responseJson->MaxTenure);
							$ROI_default 						= xss_filter($responseJson->ROIDefault);
							$ROI_actual 						= xss_filter($responseJson->ROIActual);
							$processing_fee_default = xss_filter($responseJson->ProcessingFeeDefault);
							$processing_fee_actual 	= xss_filter($responseJson->ProcessingFeeActual);
							$minimum_amt 						= xss_filter(ceil($responseJson->MinimumAmout));
							$maximum_amt 						= xss_filter(ceil($responseJson->MaxAmount));
							$processing_fee 				= $processing_fee_actual;
							$interest 							= $ROI_actual;
						
							$net_income 			= $salary - $obligation;
							$maximumloanamtemi 		= calculate_emi($maximum_amt, $ROI_actual, $max_tenure);
							
							$interest_default 		= $ROI_default / 1200;
							$emi_default 			= ceil($interest_default * -$maximum_amt * pow((1 + $interest_default), $max_tenure) / (1 - pow((1 + $interest_default), $max_tenure)));
							$emi_difference 		= $emi_default -  $maximumloanamtemi;
							$actualloanEMI 			= $maximumloanamtemi;

							$_SESSION['personal_details']['companyname'] 						= xss_filter($requestJson[0]->CompanyName);
							$_SESSION['personal_details']['emailid'] 								= xss_filter($requestJson[0]->PersonalEmailID);
							$_SESSION['personal_details']['salary'] 								= $salary;
							$_SESSION['personal_details']['mobileno'] 							= xss_filter($requestJson[0]->MobileNo);
							$_SESSION['personal_details']['obligation'] 						= $obligation;
							$_SESSION['personal_details']['city'] 									= xss_filter($requestJson[0]->City);
							$_SESSION['personal_details']['maxloanamt'] 						= $maximum_amt;
							$_SESSION['personal_details']['minloanamt'] 						= $minimum_amt;
							$_SESSION['personal_details']['actualloanEMI'] 					= $actualloanEMI;
							$_SESSION['personal_details']['roi_actual'] 						= $ROI_actual;
							$_SESSION['personal_details']['roi_default'] 						= $ROI_default;
							$_SESSION['personal_details']['actual_tenure']					= $max_tenure;
							$_SESSION['personal_details']['tenure'] 								= $max_tenure;
							$_SESSION['personal_details']['processing_fee_actual'] 	= $processing_fee_actual;
							$_SESSION['personal_details']['processing_fee_default'] = $processing_fee_default;
							$_SESSION['personal_details']['emi_diff'] 							= $emi_difference;
							$_SESSION['personal_details']['CRMLeadID'] 							= xss_filter($responseJson->CRMLeadID);
							echo "page1";
							exit;
						}
					}
					if($jsonDecode->PageNumber == '4') {
						$obligation 						= xss_filter($requestJson[1]->MonthlyObligation);
						$salary 								= xss_filter($requestJson[1]->MonthlySalary);
						$max_tenure 						= round(xss_filter($responseJson->MaxTenure),2);
						$ROI_default 						= round(xss_filter($responseJson->ROIDefault),2);
						$ROI_actual 						= round(xss_filter($responseJson->ROIActual),2);
						$processing_fee_default = round(xss_filter($responseJson->ProcessingFeeDefault),2);
						$processing_fee_actual 	= round(xss_filter($responseJson->ProcessingFeeActual),2);
						$minimum_amt 						= round(100000,2);
						$maximum_amt 						= round(xss_filter(ceil($responseJson->MaxAmount)),2);
						$processing_fee 				= $processing_fee_actual;
						$interest 							= $ROI_actual;
						
						$net_income 				= $salary - $obligation;
						$maximumloanamtemi 	= calculate_emi($maximum_amt, $ROI_actual, $max_tenure);
						$interest_default 	= $ROI_default / 1200;
						$emi_default 				= ceil($interest_default * -$maximum_amt * pow((1 + $interest_default), $max_tenure) / (1 - pow((1 + $interest_default), $max_tenure)));
						$emi_difference 		= $emi_default -  $maximumloanamtemi;
						$actualloanEMI 			= $maximumloanamtemi;

						if($minimum_amt < 100000){
							// Not eligible for loan
							echo "declined";
							exit;
						}

						$_SESSION['personal_details']['applicantname']					= xss_filter($requestJson[1]->FName);
						$_SESSION['personal_details']['lastname']								= xss_filter($requestJson[1]->LName);
						$_SESSION['personal_details']['middlename']							= xss_filter($requestJson[1]->MName);
						$_SESSION['personal_details']['gender']									= xss_filter($requestJson[1]->Gender);
						$_SESSION['personal_details']['panno']									= xss_filter($requestJson[1]->PAN);
						$_SESSION['personal_details']['dob']										= xss_filter($requestJson[1]->DOB);
						$_SESSION['personal_details']['mobileno']								= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['alternatemobileno']			= xss_filter($requestJson[1]->AlternateMobileNo);
						$_SESSION['personal_details']['emailid']								= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['permanentaddress1'] 			= xss_filter($requestJson[1]->PermanentAddress1);
						$_SESSION['personal_details']['permanentaddress2'] 			= xss_filter($requestJson[1]->PermanentAddress2);
						$_SESSION['personal_details']['permanentaddress3']			= xss_filter($requestJson[1]->PermanentAddress3);
						$_SESSION['personal_details']['permanentpincode']				= xss_filter($requestJson[1]->PermanentPin);
						$_SESSION['personal_details']['perm_state_code']				= xss_filter($requestJson[1]->PermanentState);
						$_SESSION['personal_details']['perm_city_code']					= xss_filter($requestJson[1]->PermanentCity);
						$_SESSION['personal_details']['currentaddress1']				= xss_filter($requestJson[1]->CurrentAddress1);
						$_SESSION['personal_details']['currentaddress2']				= xss_filter($requestJson[1]->CurrentAddress2);
						$_SESSION['personal_details']['currentaddress3']				= xss_filter($requestJson[1]->CurrentAddress3);
						$_SESSION['personal_details']['currentpincode']					= xss_filter($requestJson[1]->CurrentPin);
						$_SESSION['personal_details']['curr_state_code']				= xss_filter($requestJson[1]->CurrentState);
						$_SESSION['personal_details']['curr_city_code']					= xss_filter($requestJson[1]->CurrentCity);
						$_SESSION['personal_details']['workexperiance']					= xss_filter($requestJson[1]->CurrentWorkExp);
						$_SESSION['personal_details']['totworkexperiance']			= xss_filter($requestJson[1]->TotalWorkExp);
						$_SESSION['personal_details']['companyname'] 						= xss_filter($requestJson[1]->CompanyName);
						$_SESSION['personal_details']['emailid'] 								= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['salary'] 								= $salary;
						$_SESSION['personal_details']['mobileno'] 							= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['obligation'] 						= $obligation;
						$_SESSION['personal_details']['city'] 									= xss_filter($requestJson[1]->City);
						$_SESSION['personal_details']['maxloanamt'] 						= $maximum_amt;
						$_SESSION['personal_details']['minloanamt'] 						= $minimum_amt;
						$_SESSION['personal_details']['actualloanEMI'] 					= $actualloanEMI;
						$_SESSION['personal_details']['roi_actual'] 						= $ROI_actual;
						$_SESSION['personal_details']['roi_default'] 						= $ROI_default;
						$_SESSION['personal_details']['actual_tenure']					= $max_tenure;
						$_SESSION['personal_details']['tenure'] 								= $max_tenure;
						$_SESSION['personal_details']['processing_fee_actual'] 	= $processing_fee_actual;
						$_SESSION['personal_details']['processing_fee_default'] = $processing_fee_default;
						$_SESSION['personal_details']['emi_diff'] 							= $emi_difference;
						$_SESSION['personal_details']['appliedloanamt']					= xss_filter($requestJson[1]->AppliedLoanamount);
						$_SESSION['personal_details']['processing_fee'] 				= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['ProspectNumber'] 				= xss_filter($responseJson->ProspectNumber);
						$_SESSION['personal_details']['CRMLeadID'] 							= xss_filter($responseJson->CRMLeadID);
						echo "page4";
						exit;
					}
					if($jsonDecode->PageNumber == '5') {
						//echo '<pre>'; print_r($jsonDecode); echo '</pre>';
						//echo '<pre>'; print_r($requestJson); echo '</pre>';
						//echo '<pre>'; print_r($responseJson); echo '</pre>';
						//exit;
						/*------------------From 2nd object of the array------------------------*/
						$_SESSION['personal_details']['CRMLeadID']							= xss_filter($requestJson[1]->CRMLeadID);
						$_SESSION['personal_details']['companyname'] 						= xss_filter($requestJson[0]->CompanyName);
						$_SESSION['personal_details']['salary'] 								= xss_filter($requestJson[0]->MonthlySalary);
						$_SESSION['personal_details']['obligation'] 						= xss_filter($requestJson[0]->MonthlyObligation);
						$_SESSION['personal_details']['emailid']								= xss_filter($requestJson[0]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno']								= xss_filter($requestJson[0]->MobileNo);
						$_SESSION['personal_details']['alternatemobileno']			= xss_filter($requestJson[1]->AlternateMobileNo);
						$_SESSION['personal_details']['kycflag'] 								= xss_filter($requestJson[1]->KYCFlag);
						$_SESSION['personal_details']['applicantname']					= xss_filter($requestJson[1]->FName);
						$_SESSION['personal_details']['lastname']								= xss_filter($requestJson[1]->LName);
						$_SESSION['personal_details']['middlename']							= xss_filter($requestJson[1]->MName);
						$_SESSION['personal_details']['gender']									= xss_filter($requestJson[1]->Gender);
						$_SESSION['personal_details']['panno']									= xss_filter($requestJson[1]->PAN);
						$_SESSION['personal_details']['dob']										= xss_filter($requestJson[1]->DOB);
						$_SESSION['personal_details']['permanentaddress1'] 			= xss_filter($requestJson[1]->PermanentAddress1);
						$_SESSION['personal_details']['permanentaddress2'] 			= xss_filter($requestJson[1]->PermanentAddress2);
						$_SESSION['personal_details']['permanentaddress3']			= xss_filter($requestJson[1]->PermanentAddress3);
						$_SESSION['personal_details']['permanentpincode']				= xss_filter($requestJson[1]->PermanentPin);
						$_SESSION['personal_details']['perm_state_code']				= xss_filter($requestJson[1]->PermanentState);
						$_SESSION['personal_details']['perm_city_code']					= xss_filter($requestJson[1]->PermanentCity);
						$_SESSION['personal_details']['currentaddress1']				= xss_filter($requestJson[1]->CurrentAddress1);
						$_SESSION['personal_details']['currentaddress2']				= xss_filter($requestJson[1]->CurrentAddress2);
						$_SESSION['personal_details']['currentaddress3']				= xss_filter($requestJson[1]->CurrentAddress3);
						$_SESSION['personal_details']['currentpincode']					= xss_filter($requestJson[1]->CurrentPin);
						$_SESSION['personal_details']['curr_state_code']				= xss_filter($requestJson[1]->CurrentState);
						$_SESSION['personal_details']['curr_city_code']					= xss_filter($requestJson[1]->CurrentCity);
						$_SESSION['personal_details']['workexperiance']					= xss_filter($requestJson[1]->CurrentWorkExp);
						$_SESSION['personal_details']['totworkexperiance']			= xss_filter($requestJson[1]->TotalWorkExp);
						$_SESSION['personal_details']['emailid'] 								= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno'] 							= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['appliedloanamt'] 				= xss_filter($requestJson[1]->AppliedLoanamount);
						$_SESSION['personal_details']['minloanamt'] 						= 100000;
						$_SESSION['personal_details']['tenure'] 								= $_SESSION['personal_details']['actual_tenure'] = xss_filter($requestJson[1]->Tenure);
						$_SESSION['personal_details']['roi_actual'] 						= xss_filter($requestJson[1]->ROI);
						$_SESSION['personal_details']['processing_fee_actual'] 	= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['actualloanEMI'] 					= xss_filter($requestJson[1]->Emi);
						$_SESSION['personal_details']['totalamountpayable'] 		= xss_filter($requestJson[1]->TotalPayableAmount);
						/*------------------From 2nd object of the array Ends------------------------*/
						/* ---------------From 3rd object of an array starts. ------------------------*/
						$_SESSION['personal_details']['ProspectNumber'] 				= xss_filter($requestJson[2]->ProspectNumber);
						$_SESSION['personal_details']['residencetype'] 					= xss_filter($requestJson[2]->ResidenceType);
						$_SESSION['personal_details']['education']							= xss_filter($requestJson[2]->Education);
						$_SESSION['personal_details']['marritalstatus']					= xss_filter($requestJson[2]->MaritalStatus);
						$_SESSION['personal_details']['loanpurpose']						= xss_filter($requestJson[2]->PurposeofLoan);
						$_SESSION['personal_details']['residencestability']			= xss_filter($requestJson[2]->ResidenceStability);
							/* ---------------From 3rd object of an array ends-------------*/
						/*-----------------CIBIL SESSION STARTS-----------------*/
						$_SESSION['CIBIL']['cibilResponse'] 				= xss_filter($responseJson->CibilResponse);
						$_SESSION['CIBIL']['status'] 								= xss_filter($responseJson->Status);
						$_SESSION['CIBIL']['revised_MaxAmount'] 		= round(xss_filter($responseJson->MaxAmount));
						$_SESSION['CIBIL']['revised_Tenure'] 				= xss_filter($responseJson->Tenure);
						$_SESSION['CIBIL']['revised_EMI'] 					= round(xss_filter($responseJson->EMI));
						$_SESSION['CIBIL']['revised_ProcessingFee'] = round(xss_filter($responseJson->ProcessingFee));
						$_SESSION['CIBIL']['revised_ROI'] 					= xss_filter($responseJson->ROI);
						/*-----------------CIBIL SESSION ENDS--------------------*/
						echo "page5";
						exit;
					}
					
					if($jsonDecode->PageNumber == '6') {
						//echo '<pre>'; print_r($jsonDecode); echo '</pre>';
						//echo '<pre>'; print_r($requestJson); echo '</pre>';
						//echo '<pre>'; print_r($responseJson); echo '</pre>';
						//exit;
						/*------------------From 2nd object of the array------------------------*/
						$_SESSION['personal_details']['CRMLeadID']							= xss_filter($requestJson[1]->CRMLeadID);
						$_SESSION['personal_details']['companyname'] 						= xss_filter($requestJson[0]->CompanyName);
						$_SESSION['personal_details']['salary'] 								= xss_filter($requestJson[0]->MonthlySalary);
						$_SESSION['personal_details']['obligation'] 						= xss_filter($requestJson[0]->MonthlyObligation);
						$_SESSION['personal_details']['emailid']								= xss_filter($requestJson[0]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno']								= xss_filter($requestJson[0]->MobileNo);
						$_SESSION['personal_details']['alternatemobileno']			= xss_filter($requestJson[1]->AlternateMobileNo);
						$_SESSION['personal_details']['kycflag'] 								= xss_filter($requestJson[1]->KYCFlag);
						$_SESSION['personal_details']['applicantname']					= xss_filter($requestJson[1]->FName);
						$_SESSION['personal_details']['lastname']								= xss_filter($requestJson[1]->LName);
						$_SESSION['personal_details']['middlename']							= xss_filter($requestJson[1]->MName);
						$_SESSION['personal_details']['gender']									= xss_filter($requestJson[1]->Gender);
						$_SESSION['personal_details']['panno']									= xss_filter($requestJson[1]->PAN);
						$_SESSION['personal_details']['dob']										= xss_filter($requestJson[1]->DOB);
						$_SESSION['personal_details']['permanentaddress1'] 			= xss_filter($requestJson[1]->PermanentAddress1);
						$_SESSION['personal_details']['permanentaddress2'] 			= xss_filter($requestJson[1]->PermanentAddress2);
						$_SESSION['personal_details']['permanentaddress3']			= xss_filter($requestJson[1]->PermanentAddress3);
						$_SESSION['personal_details']['permanentpincode']				= xss_filter($requestJson[1]->PermanentPin);
						$_SESSION['personal_details']['perm_state_code']				= xss_filter($requestJson[1]->PermanentState);
						$_SESSION['personal_details']['perm_city_code']					= xss_filter($requestJson[1]->PermanentCity);
						$_SESSION['personal_details']['currentaddress1']				= xss_filter($requestJson[1]->CurrentAddress1);
						$_SESSION['personal_details']['currentaddress2']				= xss_filter($requestJson[1]->CurrentAddress2);
						$_SESSION['personal_details']['currentaddress3']				= xss_filter($requestJson[1]->CurrentAddress3);
						$_SESSION['personal_details']['currentpincode']					= xss_filter($requestJson[1]->CurrentPin);
						$_SESSION['personal_details']['curr_state_code']				= xss_filter($requestJson[1]->CurrentState);
						$_SESSION['personal_details']['curr_city_code']					= xss_filter($requestJson[1]->CurrentCity);
						$_SESSION['personal_details']['workexperiance']					= xss_filter($requestJson[1]->CurrentWorkExp);
						$_SESSION['personal_details']['totworkexperiance']			= xss_filter($requestJson[1]->TotalWorkExp);
						$_SESSION['personal_details']['emailid'] 								= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno'] 							= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['appliedloanamt'] 				= xss_filter($requestJson[1]->AppliedLoanamount);
						$_SESSION['personal_details']['minloanamt'] 						= 100000;
						$_SESSION['personal_details']['tenure'] 								= xss_filter($requestJson[1]->Tenure);
						$_SESSION['personal_details']['roi_actual'] 						= xss_filter($requestJson[1]->ROI);
						$_SESSION['personal_details']['processing_fee_actual']	= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['actualloanEMI'] 					= xss_filter($requestJson[1]->Emi);
						$_SESSION['personal_details']['totalamountpayable'] 		= xss_filter($requestJson[1]->TotalPayableAmount);
						/*------------------From 2nd object of the array Ends------------------------*/
						/* ---------------From 3rd object of an array starts. ------------------------*/
						$_SESSION['personal_details']['ProspectNumber'] 		= xss_filter($requestJson[2]->ProspectNumber);
						$_SESSION['personal_details']['residencetype'] 			= xss_filter($requestJson[2]->ResidenceType);
						$_SESSION['personal_details']['education']					= xss_filter($requestJson[2]->Education);
						$_SESSION['personal_details']['marritalstatus']			= xss_filter($requestJson[2]->MaritalStatus);
						$_SESSION['personal_details']['loanpurpose']				= xss_filter($requestJson[2]->PurposeofLoan);
						$_SESSION['personal_details']['residencestability']	= xss_filter($requestJson[2]->ResidenceStability);
							/* ---------------From 3rd object of an array ends-------------*/
						/*-----------------CIBIL SESSION STARTS-----------------*/

						$_SESSION['personal_details']['appliedloanamt'] 				= round(xss_filter($requestJson[3]->AppliedLoanamount));
						$_SESSION['personal_details']['tenure'] 								= xss_filter($requestJson[3]->Tenure);
						$_SESSION['personal_details']['actualloanEMI'] 					= round(xss_filter($requestJson[3]->Emi));
						$_SESSION['personal_details']['processing_fee'] 				= round(xss_filter($requestJson[3]->Processingfee));
						$_SESSION['CIBIL']['revised_ROI'] 											= xss_filter($requestJson[3]->ROI);
						/*-----------------CIBIL SESSION ENDS--------------------*/
						echo "page6";
						exit;
					}
					
					if($jsonDecode->PageNumber == '8') {
						//echo '<pre>'; print_r($jsonDecode); echo '</pre>';
						//echo '<pre>'; print_r($requestJson); echo '</pre>';
						//echo '<pre>'; print_r($responseJson); echo '</pre>';
						//exit;
						$_SESSION['doc_uploads'] = '';
						$count = count($requestJson);
						for($i=4; $i<$count; $i++) {
							$_SESSION['doc_uploads'][] = $requestJson[$i];
						}
						/*------------------From 2nd object of the array------------------------*/
						$_SESSION['personal_details']['CRMLeadID']				= xss_filter($requestJson[1]->CRMLeadID);
						$_SESSION['personal_details']['companyname'] 			= xss_filter($requestJson[0]->CompanyName);
						$_SESSION['personal_details']['salary'] 				= xss_filter($requestJson[0]->MonthlySalary);
						$_SESSION['personal_details']['obligation'] 			= xss_filter($requestJson[0]->MonthlyObligation);
						$_SESSION['personal_details']['emailid']				= xss_filter($requestJson[0]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno']				= xss_filter($requestJson[0]->MobileNo);
						$_SESSION['personal_details']['alternatemobileno']		= xss_filter($requestJson[1]->AlternateMobileNo);
						$_SESSION['personal_details']['kycflag'] 				= xss_filter($requestJson[1]->KYCFlag);
						$_SESSION['personal_details']['applicantname']			= xss_filter($requestJson[1]->FName);
						$_SESSION['personal_details']['lastname']				= xss_filter($requestJson[1]->LName);
						$_SESSION['personal_details']['middlename']				= xss_filter($requestJson[1]->MName);
						$_SESSION['personal_details']['gender']					= xss_filter($requestJson[1]->Gender);
						$_SESSION['personal_details']['panno']					= xss_filter($requestJson[1]->PAN);
						$_SESSION['personal_details']['dob']					= xss_filter($requestJson[1]->DOB);
						$_SESSION['personal_details']['permanentaddress1'] 		= xss_filter($requestJson[1]->PermanentAddress1);
						$_SESSION['personal_details']['permanentaddress2'] 		= xss_filter($requestJson[1]->PermanentAddress2);
						$_SESSION['personal_details']['permanentaddress3']		= xss_filter($requestJson[1]->PermanentAddress3);
						$_SESSION['personal_details']['permanentpincode']		= xss_filter($requestJson[1]->PermanentPin);
						$_SESSION['personal_details']['perm_state_code']		= xss_filter($requestJson[1]->PermanentState);
						$_SESSION['personal_details']['perm_city_code']			= xss_filter($requestJson[1]->PermanentCity);
						$_SESSION['personal_details']['currentaddress1']		= xss_filter($requestJson[1]->CurrentAddress1);
						$_SESSION['personal_details']['currentaddress2']		= xss_filter($requestJson[1]->CurrentAddress2);
						$_SESSION['personal_details']['currentaddress3']		= xss_filter($requestJson[1]->CurrentAddress3);
						$_SESSION['personal_details']['currentpincode']			= xss_filter($requestJson[1]->CurrentPin);
						$_SESSION['personal_details']['curr_state_code']		= xss_filter($requestJson[1]->CurrentState);
						$_SESSION['personal_details']['curr_city_code']			= xss_filter($requestJson[1]->CurrentCity);
						$_SESSION['personal_details']['workexperiance']			= xss_filter($requestJson[1]->CurrentWorkExp);
						$_SESSION['personal_details']['totworkexperiance']		= xss_filter($requestJson[1]->TotalWorkExp);
						$_SESSION['personal_details']['emailid'] 				= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno'] 				= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['appliedloanamt'] 		= xss_filter($requestJson[3]->AppliedLoanamount);
						$_SESSION['personal_details']['minloanamt'] 			= 100000;
						$_SESSION['personal_details']['tenure'] 				= xss_filter($requestJson[1]->Tenure);
						$_SESSION['personal_details']['roi_actual'] 			= xss_filter($requestJson[1]->ROI);
						$_SESSION['personal_details']['processing_fee_actual'] 	= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['processing_fee'] 		= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['actualloanEMI'] 			= xss_filter($requestJson[1]->Emi);
						$_SESSION['personal_details']['totalamountpayable'] 	= xss_filter($requestJson[1]->TotalPayableAmount);
						/*------------------From 2nd object of the array Ends------------------------*/
						/* ---------------From 3rd object of an array starts. ------------------------*/
						$_SESSION['personal_details']['ProspectNumber'] 		= xss_filter($requestJson[2]->ProspectNumber);
						$_SESSION['personal_details']['residencetype'] 			= xss_filter($requestJson[2]->ResidenceType);
						$_SESSION['personal_details']['education']				= xss_filter($requestJson[2]->Education);
						$_SESSION['personal_details']['marritalstatus']			= xss_filter($requestJson[2]->MaritalStatus);
						$_SESSION['personal_details']['loanpurpose']			= xss_filter($requestJson[2]->PurposeofLoan);
						$_SESSION['personal_details']['residencestability']		= xss_filter($requestJson[2]->ResidenceStability);
							/* ---------------From 3rd object of an array ends-------------*/
						/*-----------------CIBIL SESSION STARTS-----------------*/

						 $_SESSION['CIBIL']['revised_MaxAmount'] 				= round(xss_filter($requestJson[3]->AppliedLoanamount));
						 $_SESSION['CIBIL']['revised_Tenure'] 					= xss_filter($requestJson[3]->Tenure);
						 $_SESSION['CIBIL']['revised_EMI'] 						= round(xss_filter($requestJson[3]->Emi));
						 $_SESSION['CIBIL']['revised_ProcessingFee'] 			= round(xss_filter($requestJson[3]->Processingfee));
						 $_SESSION['CIBIL']['revised_ROI'] 						= xss_filter($requestJson[3]->ROI);
						/*-----------------CIBIL SESSION ENDS--------------------*/


						echo "page8";
						exit;
					}
					
					if($jsonDecode->PageNumber == '9') {
						//echo '<pre>'; print_r($jsonDecode); echo '</pre>';
						//echo '<pre>'; print_r($requestJson); echo '</pre>';
						//echo '<pre>'; print_r($responseJson); echo '</pre>';
						//exit;
						$_SESSION['doc_uploads'] = '';
						$count = count($requestJson);
						for($i=4; $i<$count; $i++) {
							$_SESSION['doc_uploads'][] = $requestJson[$i];
						}
						/*------------------From 2nd object of the array------------------------*/
						$_SESSION['personal_details']['CRMLeadID']				= xss_filter($requestJson[1]->CRMLeadID);
						$_SESSION['personal_details']['companyname'] 			= xss_filter($requestJson[0]->CompanyName);
						$_SESSION['personal_details']['salary'] 				= xss_filter($requestJson[0]->MonthlySalary);
						$_SESSION['personal_details']['obligation'] 			= xss_filter($requestJson[0]->MonthlyObligation);
						$_SESSION['personal_details']['emailid']				= xss_filter($requestJson[0]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno']				= xss_filter($requestJson[0]->MobileNo);
						$_SESSION['personal_details']['alternatemobileno']		= xss_filter($requestJson[1]->AlternateMobileNo);
						$_SESSION['personal_details']['kycflag'] 				= xss_filter($requestJson[1]->KYCFlag);
						$_SESSION['personal_details']['applicantname']			= xss_filter($requestJson[1]->FName);
						$_SESSION['personal_details']['lastname']				= xss_filter($requestJson[1]->LName);
						$_SESSION['personal_details']['middlename']				= xss_filter($requestJson[1]->MName);
						$_SESSION['personal_details']['gender']					= xss_filter($requestJson[1]->Gender);
						$_SESSION['personal_details']['panno']					= xss_filter($requestJson[1]->PAN);
						$_SESSION['personal_details']['dob']					= xss_filter($requestJson[1]->DOB);
						$_SESSION['personal_details']['permanentaddress1'] 		= xss_filter($requestJson[1]->PermanentAddress1);
						$_SESSION['personal_details']['permanentaddress2'] 		= xss_filter($requestJson[1]->PermanentAddress2);
						$_SESSION['personal_details']['permanentaddress3']		= xss_filter($requestJson[1]->PermanentAddress3);
						$_SESSION['personal_details']['permanentpincode']		= xss_filter($requestJson[1]->PermanentPin);
						$_SESSION['personal_details']['perm_state_code']		= xss_filter($requestJson[1]->PermanentState);
						$_SESSION['personal_details']['perm_city_code']			= xss_filter($requestJson[1]->PermanentCity);
						$_SESSION['personal_details']['currentaddress1']		= xss_filter($requestJson[1]->CurrentAddress1);
						$_SESSION['personal_details']['currentaddress2']		= xss_filter($requestJson[1]->CurrentAddress2);
						$_SESSION['personal_details']['currentaddress3']		= xss_filter($requestJson[1]->CurrentAddress3);
						$_SESSION['personal_details']['currentpincode']			= xss_filter($requestJson[1]->CurrentPin);
						$_SESSION['personal_details']['curr_state_code']		= xss_filter($requestJson[1]->CurrentState);
						$_SESSION['personal_details']['curr_city_code']			= xss_filter($requestJson[1]->CurrentCity);
						$_SESSION['personal_details']['workexperiance']			= xss_filter($requestJson[1]->CurrentWorkExp);
						$_SESSION['personal_details']['totworkexperiance']		= xss_filter($requestJson[1]->TotalWorkExp);
						$_SESSION['personal_details']['emailid'] 				= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno'] 				= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['appliedloanamt'] 		= xss_filter($requestJson[3]->AppliedLoanamount);
						$_SESSION['personal_details']['minloanamt'] 			= 100000;
						$_SESSION['personal_details']['tenure'] 				= xss_filter($requestJson[1]->Tenure);
						$_SESSION['personal_details']['roi_actual'] 			= xss_filter($requestJson[1]->ROI);
						$_SESSION['personal_details']['processing_fee_actual'] 	= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['processing_fee'] 		= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['actualloanEMI'] 			= xss_filter($requestJson[1]->Emi);
						$_SESSION['personal_details']['totalamountpayable'] 	= xss_filter($requestJson[1]->TotalPayableAmount);
						/*------------------From 2nd object of the array Ends------------------------*/
						/* ---------------From 3rd object of an array starts. ------------------------*/
						$_SESSION['personal_details']['ProspectNumber'] 		= xss_filter($requestJson[2]->ProspectNumber);
						$_SESSION['personal_details']['residencetype'] 			= xss_filter($requestJson[2]->ResidenceType);
						$_SESSION['personal_details']['education']				= xss_filter($requestJson[2]->Education);
						$_SESSION['personal_details']['marritalstatus']			= xss_filter($requestJson[2]->MaritalStatus);
						$_SESSION['personal_details']['loanpurpose']			= xss_filter($requestJson[2]->PurposeofLoan);
						$_SESSION['personal_details']['residencestability']		= xss_filter($requestJson[2]->ResidenceStability);
							/* ---------------From 3rd object of an array ends-------------*/
						/*-----------------CIBIL SESSION STARTS-----------------*/

						 $_SESSION['CIBIL']['revised_MaxAmount'] 				= round(xss_filter($requestJson[3]->AppliedLoanamount));
						 $_SESSION['CIBIL']['revised_Tenure'] 					= xss_filter($requestJson[3]->Tenure);
						 $_SESSION['CIBIL']['revised_EMI'] 						= round(xss_filter($requestJson[3]->Emi));
						 $_SESSION['CIBIL']['revised_ProcessingFee'] 			= round(xss_filter($requestJson[3]->Processingfee));
						 $_SESSION['CIBIL']['revised_ROI'] 						= xss_filter($requestJson[3]->ROI);
						/*-----------------CIBIL SESSION ENDS--------------------*/


						echo "page9";
						exit;
					}	
					
					
					if($jsonDecode->PageNumber == '10') {
						//echo '<pre>'; print_r($jsonDecode); echo '</pre>';
						//echo '<pre>'; print_r($requestJson); echo '</pre>';
						//echo '<pre>'; print_r($responseJson); echo '</pre>';
						//exit;
						/*------------------From 2nd object of the array------------------------*/
						$_SESSION['personal_details']['CRMLeadID']							= xss_filter($requestJson[1]->CRMLeadID);
						$_SESSION['personal_details']['companyname'] 						= xss_filter($requestJson[0]->CompanyName);
						$_SESSION['personal_details']['salary'] 								= xss_filter($requestJson[0]->MonthlySalary);
						$_SESSION['personal_details']['obligation'] 						= xss_filter($requestJson[0]->MonthlyObligation);
						$_SESSION['personal_details']['emailid']								= xss_filter($requestJson[0]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno']								= xss_filter($requestJson[0]->MobileNo);
						$_SESSION['personal_details']['alternatemobileno']			= xss_filter($requestJson[1]->AlternateMobileNo);
						$_SESSION['personal_details']['kycflag'] 								= xss_filter($requestJson[1]->KYCFlag);
						$_SESSION['personal_details']['applicantname']					= xss_filter($requestJson[1]->FName);
						$_SESSION['personal_details']['lastname']								= xss_filter($requestJson[1]->LName);
						$_SESSION['personal_details']['middlename']							= xss_filter($requestJson[1]->MName);
						$_SESSION['personal_details']['gender']									= xss_filter($requestJson[1]->Gender);
						$_SESSION['personal_details']['panno']									= xss_filter($requestJson[1]->PAN);
						$_SESSION['personal_details']['dob']										= xss_filter($requestJson[1]->DOB);
						$_SESSION['personal_details']['permanentaddress1'] 			= xss_filter($requestJson[1]->PermanentAddress1);
						$_SESSION['personal_details']['permanentaddress2'] 			= xss_filter($requestJson[1]->PermanentAddress2);
						$_SESSION['personal_details']['permanentaddress3']			= xss_filter($requestJson[1]->PermanentAddress3);
						$_SESSION['personal_details']['permanentpincode']				= xss_filter($requestJson[1]->PermanentPin);
						$_SESSION['personal_details']['perm_state_code']				= xss_filter($requestJson[1]->PermanentState);
						$_SESSION['personal_details']['perm_city_code']					= xss_filter($requestJson[1]->PermanentCity);
						$_SESSION['personal_details']['currentaddress1']				= xss_filter($requestJson[1]->CurrentAddress1);
						$_SESSION['personal_details']['currentaddress2']				= xss_filter($requestJson[1]->CurrentAddress2);
						$_SESSION['personal_details']['currentaddress3']				= xss_filter($requestJson[1]->CurrentAddress3);
						$_SESSION['personal_details']['currentpincode']					= xss_filter($requestJson[1]->CurrentPin);
						$_SESSION['personal_details']['curr_state_code']				= xss_filter($requestJson[1]->CurrentState);
						$_SESSION['personal_details']['curr_city_code']					= xss_filter($requestJson[1]->CurrentCity);
						$_SESSION['personal_details']['workexperiance']					= xss_filter($requestJson[1]->CurrentWorkExp);
						$_SESSION['personal_details']['totworkexperiance']			= xss_filter($requestJson[1]->TotalWorkExp);
						$_SESSION['personal_details']['emailid'] 								= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno'] 							= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['appliedloanamt'] 				= xss_filter($requestJson[1]->AppliedLoanamount);
						$_SESSION['personal_details']['minloanamt'] 						= 100000;
						$_SESSION['personal_details']['tenure'] 								= xss_filter($requestJson[1]->Tenure);
						$_SESSION['personal_details']['roi_actual'] 						= xss_filter($requestJson[1]->ROI);
						$_SESSION['personal_details']['processing_fee_actual']	= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['actualloanEMI'] 					= xss_filter($requestJson[1]->Emi);
						$_SESSION['personal_details']['totalamountpayable'] 		= xss_filter($requestJson[1]->TotalPayableAmount);
						/*------------------From 2nd object of the array Ends------------------------*/
						/* ---------------From 3rd object of an array starts. ------------------------*/
						$_SESSION['personal_details']['ProspectNumber'] 		= xss_filter($requestJson[2]->ProspectNumber);
						$_SESSION['personal_details']['residencetype'] 			= xss_filter($requestJson[2]->ResidenceType);
						$_SESSION['personal_details']['education']					= xss_filter($requestJson[2]->Education);
						$_SESSION['personal_details']['marritalstatus']			= xss_filter($requestJson[2]->MaritalStatus);
						$_SESSION['personal_details']['loanpurpose']				= xss_filter($requestJson[2]->PurposeofLoan);
						$_SESSION['personal_details']['residencestability']	= xss_filter($requestJson[2]->ResidenceStability);
							/* ---------------From 3rd object of an array ends-------------*/
						$_SESSION['CIBIL']['revised_MaxAmount']			= '';
						$_SESSION['CIBIL']['revised_Tenure']				= '';
						$_SESSION['CIBIL']['revised_EMI']						= '';
						$_SESSION['CIBIL']['revised_ProcessingFee']	= '';
						$_SESSION['CIBIL']['revised_ROI']						= '';
						$_SESSION['CIBIL']['revised_ROI']						= '';
						/*-----------------CIBIL SESSION STARTS-----------------*/
						// $_SESSION['CIBIL']['cibilResponse'] 					= xss_filter($requestJson[4]->CibilResponse);
						// $_SESSION['CIBIL']['status'] 							= xss_filter($requestJson[4]->Status);
						// $_SESSION['CIBIL']['revised_MaxAmount'] 				= round(xss_filter($requestJson[4]->MaxAmount));
						// $_SESSION['CIBIL']['revised_Tenure'] 					= xss_filter($requestJson[4]->Tenure);
						// $_SESSION['CIBIL']['revised_EMI'] 						= round(xss_filter($requestJson[4]->EMI));
						// $_SESSION['CIBIL']['revised_ProcessingFee'] 			= round(xss_filter($requestJson[4]->ProcessingFee));
						// $_SESSION['CIBIL']['revised_ROI'] 						= xss_filter($requestJson[4]->ROI);
						/*-----------------CIBIL SESSION ENDS--------------------*/
						/*--------------co-applicant sessions----------------*/
						$_SESSION['co_applicant_details']['companyName'] 									= xss_filter($requestJson[3]->CoCompanyName);
						$_SESSION['co_applicant_details']['otherCompanyName'] 						= xss_filter($requestJson[3]->CoOtherCompanyName);
						$_SESSION['co_applicant_details']['relationType'] 								= xss_filter($requestJson[3]->RelationwithApplicant);
						$_SESSION['co_applicant_details']['monthlySalary']								= xss_filter($requestJson[3]->CoMonthlySalary);
						$_SESSION['co_applicant_details']['currentEmi']										= xss_filter($requestJson[3]->CoMonthlyObligation);
						$_SESSION['co_applicant_details']['applicantname']								= xss_filter($requestJson[3]->CoFName);
						$_SESSION['co_applicant_details']['lastname']											= xss_filter($requestJson[3]->CoLName);
						$_SESSION['co_applicant_details']['middlename']										= xss_filter($requestJson[3]->CoMName);
						$_SESSION['co_applicant_details']['gender']												= xss_filter($requestJson[3]->CoGender);
						$_SESSION['co_applicant_details']['panno']												= xss_filter($requestJson[3]->CoPAN);
						$_SESSION['co_applicant_details']['dob']													= xss_filter($requestJson[3]->CoDOB);
						$_SESSION['co_applicant_details']['mobileno']											= xss_filter($requestJson[3]->CoMobileNo);
						$_SESSION['co_applicant_details']['alternatemobileno']						= xss_filter($requestJson[3]->CoAlternateMobileNo);
						$_SESSION['co_applicant_details']['emailid']											= xss_filter($requestJson[3]->CoPersonalEmailID);
						$_SESSION['co_applicant_details']['permanentaddress1']						= xss_filter($requestJson[3]->CoPermanentAddress1);
						$_SESSION['co_applicant_details']['permanentaddress2']						= xss_filter($requestJson[3]->CoPermanentAddress2);
						$_SESSION['co_applicant_details']['permanentaddress3']						= xss_filter($requestJson[3]->CoPermanentAddress3);
						$_SESSION['co_applicant_details']['permanentpincode']							= xss_filter($requestJson[3]->CoPermanentPin);
						$_SESSION['co_applicant_details']['permanentstate']								= '';
						$_SESSION['co_applicant_details']['permanentcity']								= '';
						$_SESSION['co_applicant_details']['perm_state_code']							= xss_filter($requestJson[3]->CoPermanentState);
						$_SESSION['co_applicant_details']['perm_city_code']								= xss_filter($requestJson[3]->CoPermanentCity);
						$_SESSION['co_applicant_details']['currentaddress1']							= xss_filter($requestJson[3]->CoCurrentAddress1);
						$_SESSION['co_applicant_details']['currentaddress2']							= xss_filter($requestJson[3]->CoCurrentAddress2);
						$_SESSION['co_applicant_details']['currentaddress3']							= xss_filter($requestJson[3]->CoCurrentAddress3);
						$_SESSION['co_applicant_details']['currentpincode']								= xss_filter($requestJson[3]->CoCurrentPin);
						$_SESSION['co_applicant_details']['currentstate']									= '';
						$_SESSION['co_applicant_details']['currentcity']									= '';
						$_SESSION['co_applicant_details']['curr_state_code'] 							= xss_filter($requestJson[3]->CoCurrentState);
						$_SESSION['co_applicant_details']['curr_city_code']  							= xss_filter($requestJson[3]->CoCurrentCity);
						$_SESSION['co_applicant_details']['workexperiance']								= xss_filter($requestJson[3]->CoCurrentWorkExp);
						$_SESSION['co_applicant_details']['totworkexperiance']						= xss_filter($requestJson[3]->CoTotalWorkExp);
						$_SESSION['co_applicant_details']['occupation']										= xss_filter($requestJson[3]->EmploymentType);
						$_SESSION['co_applicant_details']['cnamecoappnature']							= xss_filter($requestJson[3]->NatureOfBusiness);
						$_SESSION['co_applicant_details']['cnamecoappnatureprofession']		= xss_filter($requestJson[3]->Profession);
						$_SESSION['co_applicant_details']['cnamecoappnatureconstitution']	= xss_filter($requestJson[3]->ConstitutionType);
						/*-------------------------CIBIL response for co applicant----------------------------*/

						if($responseJson->CibilResponse == '0-Yes') {
							$_SESSION['co_applicant_details']['CIBIL']['flag'] 					= 'Yes';
						} else if($responseJson->CibilResponse == '1-NO') {
							$_SESSION['co_applicant_details']['CIBIL']['flag'] 					= 'No';
						} else if($responseJson->CibilResponse == '2-Null'){
							$_SESSION['co_applicant_details']['CIBIL']['flag'] 					= 'Null';
						} else {
							$_SESSION['co_applicant_details']['CIBIL']['flag'] 					= 'No';
						}
						$_SESSION['co_applicant_details']['CIBIL']['CibilResponse'] 				= xss_filter($responseJson->CibilResponse);
						$_SESSION['co_applicant_details']['CIBIL']['CIBILTotalEMI'] 				= round(xss_filter($responseJson->CIBILTotalEMI));
						$_SESSION['co_applicant_details']['CIBIL']['MaxAmount']							= round(xss_filter($responseJson->MaxAmount));
						$_SESSION['co_applicant_details']['CIBIL']['MaxTenure'] 						= round(xss_filter($responseJson->MaxTenure));
						$_SESSION['co_applicant_details']['CIBIL']['ROIDefault']						= round(xss_filter($responseJson->ROIDefault), 2);
						$_SESSION['co_applicant_details']['CIBIL']['ROIActual']							= round(xss_filter($responseJson->ROIActual), 2 );
						$_SESSION['co_applicant_details']['CIBIL']['ProcessingFeeDefault'] 	= round(xss_filter($responseJson->ProcessingFeeDefault));
						$_SESSION['co_applicant_details']['CIBIL']['ProcessingFeeActual']		= round(xss_filter($responseJson->ProcessingFeeActual));
						if($_SESSION['co_applicant_details']['CIBIL']['flag'] == 'Null') {
							echo "page10upload";
						} else {
							echo "page10";
						}						
						exit;
					}
					
					if($jsonDecode->PageNumber == '11') {
						//echo '<pre>'; print_r($jsonDecode); echo '</pre>';
						//echo '<pre>'; print_r($requestJson); echo '</pre>';
						//echo '<pre>'; print_r($responseJson); echo '</pre>';
						//exit;
						/*------------------From 2nd object of the array------------------------*/
						$_SESSION['personal_details']['CRMLeadID']				= xss_filter($requestJson[1]->CRMLeadID);
						$_SESSION['personal_details']['companyname'] 			= xss_filter($requestJson[1]->CompanyName);
						$_SESSION['personal_details']['salary'] 				= xss_filter($requestJson[1]->MonthlySalary);
						$_SESSION['personal_details']['obligation'] 			= xss_filter($requestJson[1]->MonthlyObligation);
						$_SESSION['personal_details']['emailid']				= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno']				= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['alternatemobileno']		= xss_filter($requestJson[1]->AlternateMobileNo);
						$_SESSION['personal_details']['kycflag'] 				= xss_filter($requestJson[1]->KYCFlag);
						$_SESSION['personal_details']['applicantname']			= xss_filter($requestJson[1]->FName);
						$_SESSION['personal_details']['lastname']				= xss_filter($requestJson[1]->LName);
						$_SESSION['personal_details']['middlename']				= xss_filter($requestJson[1]->MName);
						$_SESSION['personal_details']['gender']					= xss_filter($requestJson[1]->Gender);
						$_SESSION['personal_details']['panno']					= xss_filter($requestJson[1]->PAN);
						$_SESSION['personal_details']['dob']					= xss_filter($requestJson[1]->DOB);
						$_SESSION['personal_details']['permanentaddress1'] 		= xss_filter($requestJson[1]->PermanentAddress1);
						$_SESSION['personal_details']['permanentaddress2'] 		= xss_filter($requestJson[1]->PermanentAddress2);
						$_SESSION['personal_details']['permanentaddress3']		= xss_filter($requestJson[1]->PermanentAddress3);
						$_SESSION['personal_details']['permanentpincode']		= xss_filter($requestJson[1]->PermanentPin);
						$_SESSION['personal_details']['perm_state_code']		= xss_filter($requestJson[1]->PermanentState);
						$_SESSION['personal_details']['perm_city_code']			= xss_filter($requestJson[1]->PermanentCity);
						$_SESSION['personal_details']['currentaddress1']		= xss_filter($requestJson[1]->CurrentAddress1);
						$_SESSION['personal_details']['currentaddress2']		= xss_filter($requestJson[1]->CurrentAddress2);
						$_SESSION['personal_details']['currentaddress3']		= xss_filter($requestJson[1]->CurrentAddress3);
						$_SESSION['personal_details']['currentpincode']			= xss_filter($requestJson[1]->CurrentPin);
						$_SESSION['personal_details']['curr_state_code']		= xss_filter($requestJson[1]->CurrentState);
						$_SESSION['personal_details']['curr_city_code']			= xss_filter($requestJson[1]->CurrentCity);
						$_SESSION['personal_details']['workexperiance']			= xss_filter($requestJson[1]->CurrentWorkExp);
						$_SESSION['personal_details']['totworkexperiance']		= xss_filter($requestJson[1]->TotalWorkExp);
						$_SESSION['personal_details']['emailid'] 				= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno'] 				= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['appliedloanamt'] 		= xss_filter($requestJson[4]->AppliedLoanamount);
						$_SESSION['personal_details']['minloanamt'] 			= 100000;
						$_SESSION['personal_details']['tenure'] 				= xss_filter($requestJson[4]->Tenure);
						$_SESSION['personal_details']['roi_actual'] 			= xss_filter($requestJson[1]->ROI);
						$_SESSION['personal_details']['processing_fee_actual'] 	= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['processing_fee'] 		= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['actualloanEMI'] 			= xss_filter($requestJson[1]->Emi);
						$_SESSION['personal_details']['totalamountpayable'] 	= xss_filter($requestJson[1]->TotalPayableAmount);
						/*------------------From 2nd object of the array Ends------------------------*/
						/* ---------------From 3rd object of an array starts. ------------------------*/
						$_SESSION['personal_details']['ProspectNumber'] 		= xss_filter($requestJson[2]->ProspectNumber);
						$_SESSION['personal_details']['residencetype'] 			= xss_filter($requestJson[2]->ResidenceType);
						$_SESSION['personal_details']['education']				= xss_filter($requestJson[2]->Education);
						$_SESSION['personal_details']['marritalstatus']			= xss_filter($requestJson[2]->MaritalStatus);
						$_SESSION['personal_details']['loanpurpose']			= xss_filter($requestJson[2]->PurposeofLoan);
						$_SESSION['personal_details']['residencestability']		= xss_filter($requestJson[2]->ResidenceStability);
							/* ---------------From 3rd object of an array ends-------------*/
						/*-----------------CIBIL SESSION STARTS-----------------*/
						// $_SESSION['CIBIL']['cibilResponse'] 					= xss_filter($requestJson[4]->CibilResponse);
						// $_SESSION['CIBIL']['status'] 							= xss_filter($requestJson[4]->Status);
						// $_SESSION['CIBIL']['revised_MaxAmount'] 				= round(xss_filter($requestJson[4]->MaxAmount));
						// $_SESSION['CIBIL']['revised_Tenure'] 					= xss_filter($requestJson[4]->Tenure);
						// $_SESSION['CIBIL']['revised_EMI'] 						= round(xss_filter($requestJson[4]->EMI));
						// $_SESSION['CIBIL']['revised_ProcessingFee'] 			= round(xss_filter($requestJson[4]->ProcessingFee));
						// $_SESSION['CIBIL']['revised_ROI'] 						= xss_filter($requestJson[4]->ROI);
						/*-----------------CIBIL SESSION ENDS--------------------*/

						$_SESSION['co_applicant_details']['companyName'] 					= xss_filter($requestJson[3]->CoCompanyName);
						$_SESSION['co_applicant_details']['otherCompanyName'] 				= xss_filter($requestJson[3]->CoOtherCompanyName);
						$_SESSION['co_applicant_details']['relationType'] 					= xss_filter($requestJson[3]->RelationwithApplicant);
						$_SESSION['co_applicant_details']['monthlySalary']					= xss_filter($requestJson[3]->CoMonthlySalary);
						$_SESSION['co_applicant_details']['currentEmi']						= xss_filter($requestJson[3]->CoMonthlyObligation);
						$_SESSION['co_applicant_details']['applicantname']					= xss_filter($requestJson[3]->CoFName);
						$_SESSION['co_applicant_details']['lastname']						= xss_filter($requestJson[3]->CoLName);
						$_SESSION['co_applicant_details']['middlename']						= xss_filter($requestJson[3]->CoMName);
						$_SESSION['co_applicant_details']['gender']							= xss_filter($requestJson[3]->CoGender);
						$_SESSION['co_applicant_details']['panno']							= xss_filter($requestJson[3]->CoPAN);
						$_SESSION['co_applicant_details']['dob']							= xss_filter($requestJson[3]->CoDOB);
						$_SESSION['co_applicant_details']['mobileno']						= xss_filter($requestJson[3]->CoMobileNo);
						$_SESSION['co_applicant_details']['alternatemobileno']				= xss_filter($requestJson[3]->CoAlternateMobileNo);
						$_SESSION['co_applicant_details']['emailid']						= xss_filter($requestJson[3]->CoPersonalEmailID);
						$_SESSION['co_applicant_details']['permanentaddress1']				= xss_filter($requestJson[3]->CoPermanentAddress1);
						$_SESSION['co_applicant_details']['permanentaddress2']				= xss_filter($requestJson[3]->CoPermanentAddress2);
						$_SESSION['co_applicant_details']['permanentaddress3']				= xss_filter($requestJson[3]->CoPermanentAddress3);
						$_SESSION['co_applicant_details']['permanentpincode']				= xss_filter($requestJson[3]->CoPermanentPin);
						$_SESSION['co_applicant_details']['permanentstate']					= '';
						$_SESSION['co_applicant_details']['permanentcity']					= '';
						$_SESSION['co_applicant_details']['perm_state_code']				= xss_filter($requestJson[3]->CoPermanentState);
						$_SESSION['co_applicant_details']['perm_city_code']					= xss_filter($requestJson[3]->CoPermanentCity);
						$_SESSION['co_applicant_details']['currentaddress1']				= xss_filter($requestJson[3]->CoCurrentAddress1);
						$_SESSION['co_applicant_details']['currentaddress2']				= xss_filter($requestJson[3]->CoCurrentAddress2);
						$_SESSION['co_applicant_details']['currentaddress3']				= xss_filter($requestJson[3]->CoCurrentAddress3);
						$_SESSION['co_applicant_details']['currentpincode']					= xss_filter($requestJson[3]->CoCurrentPin);
						$_SESSION['co_applicant_details']['currentstate']					= '';
						$_SESSION['co_applicant_details']['currentcity']					= '';
						$_SESSION['co_applicant_details']['curr_state_code'] 				= xss_filter($requestJson[3]->CoCurrentState);
						$_SESSION['co_applicant_details']['curr_city_code']  				= xss_filter($requestJson[3]->CoCurrentCity);
						$_SESSION['co_applicant_details']['workexperiance']					= xss_filter($requestJson[3]->CoCurrentWorkExp);
						$_SESSION['co_applicant_details']['totworkexperiance']				= xss_filter($requestJson[3]->CoTotalWorkExp);
						$_SESSION['co_applicant_details']['occupation']						= xss_filter($requestJson[3]->EmploymentType);
						$_SESSION['co_applicant_details']['cnamecoappnature']				= xss_filter($requestJson[3]->NatureOfBusiness);
						$_SESSION['co_applicant_details']['cnamecoappnatureprofession']		= xss_filter($requestJson[3]->Profession);
						$_SESSION['co_applicant_details']['cnamecoappnatureconstitution']	= xss_filter($requestJson[3]->ConstitutionType);
						
						
						$_SESSION['co_applicant_details']['CIBIL']['ROIActual']				= xss_filter($requestJson[4]->ROI);
						$_SESSION['co_applicant_details']['CIBIL']['ProcessingFeeActual']	= xss_filter($requestJson[4]->Processingfee);
						$_SESSION['co_applicant_details']['CIBIL']['MaxTenure']				= xss_filter($requestJson[4]->Tenure);
						$_SESSION['co_applicant_details']['CIBIL']['MaxAmount']				= xss_filter($requestJson[4]->AppliedLoanamount);
						
						
						echo "page11";
						exit;
					}
					
					if($jsonDecode->PageNumber == '12') {
						//echo '<pre>'; print_r($jsonDecode); echo '</pre>';
						//echo '<pre>'; print_r($requestJson); echo '</pre>';
						//echo '<pre>'; print_r($responseJson); echo '</pre>';
						//exit;
						
						$_SESSION['doc_uploads'] = '';
						$count = count($requestJson);
						for($i=5; $i<$count; $i++) {
							$_SESSION['doc_uploads'][] = $requestJson[$i];
						}
						
						
						/*------------------From 2nd object of the array------------------------*/
						$_SESSION['personal_details']['CRMLeadID']							= xss_filter($requestJson[1]->CRMLeadID);
						$_SESSION['personal_details']['companyname'] 						= xss_filter($requestJson[0]->CompanyName);
						$_SESSION['personal_details']['salary'] 								= xss_filter($requestJson[0]->MonthlySalary);
						$_SESSION['personal_details']['obligation'] 						= xss_filter($requestJson[0]->MonthlyObligation);
						$_SESSION['personal_details']['emailid']								= xss_filter($requestJson[0]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno']								= xss_filter($requestJson[0]->MobileNo);
						$_SESSION['personal_details']['alternatemobileno']			= xss_filter($requestJson[1]->AlternateMobileNo);
						$_SESSION['personal_details']['kycflag'] 								= xss_filter($requestJson[1]->KYCFlag);
						$_SESSION['personal_details']['applicantname']					= xss_filter($requestJson[1]->FName);
						$_SESSION['personal_details']['lastname']								= xss_filter($requestJson[1]->LName);
						$_SESSION['personal_details']['middlename']							= xss_filter($requestJson[1]->MName);
						$_SESSION['personal_details']['gender']									= xss_filter($requestJson[1]->Gender);
						$_SESSION['personal_details']['panno']									= xss_filter($requestJson[1]->PAN);
						$_SESSION['personal_details']['dob']										= xss_filter($requestJson[1]->DOB);
						$_SESSION['personal_details']['permanentaddress1'] 			= xss_filter($requestJson[1]->PermanentAddress1);
						$_SESSION['personal_details']['permanentaddress2'] 			= xss_filter($requestJson[1]->PermanentAddress2);
						$_SESSION['personal_details']['permanentaddress3']			= xss_filter($requestJson[1]->PermanentAddress3);
						$_SESSION['personal_details']['permanentpincode']				= xss_filter($requestJson[1]->PermanentPin);
						$_SESSION['personal_details']['perm_state_code']				= xss_filter($requestJson[1]->PermanentState);
						$_SESSION['personal_details']['perm_city_code']					= xss_filter($requestJson[1]->PermanentCity);
						$_SESSION['personal_details']['currentaddress1']				= xss_filter($requestJson[1]->CurrentAddress1);
						$_SESSION['personal_details']['currentaddress2']				= xss_filter($requestJson[1]->CurrentAddress2);
						$_SESSION['personal_details']['currentaddress3']				= xss_filter($requestJson[1]->CurrentAddress3);
						$_SESSION['personal_details']['currentpincode']					= xss_filter($requestJson[1]->CurrentPin);
						$_SESSION['personal_details']['curr_state_code']				= xss_filter($requestJson[1]->CurrentState);
						$_SESSION['personal_details']['curr_city_code']					= xss_filter($requestJson[1]->CurrentCity);
						$_SESSION['personal_details']['workexperiance']					= xss_filter($requestJson[1]->CurrentWorkExp);
						$_SESSION['personal_details']['totworkexperiance']			= xss_filter($requestJson[1]->TotalWorkExp);
						$_SESSION['personal_details']['emailid'] 								= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno'] 							= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['appliedloanamt'] 				= xss_filter($requestJson[4]->AppliedLoanamount);
						$_SESSION['personal_details']['minloanamt'] 						= 100000;
						$_SESSION['personal_details']['tenure'] 								= xss_filter($requestJson[4]->Tenure);
						$_SESSION['personal_details']['roi_actual'] 						= xss_filter($requestJson[1]->ROI);
						$_SESSION['personal_details']['processing_fee_actual']	= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['processing_fee'] 				= xss_filter($requestJson[1]->Processingfee);
						$_SESSION['personal_details']['actualloanEMI'] 					= xss_filter($requestJson[1]->Emi);
						$_SESSION['personal_details']['totalamountpayable'] 		= xss_filter($requestJson[1]->TotalPayableAmount);
						/*------------------From 2nd object of the array Ends------------------------*/
						/* ---------------From 3rd object of an array starts. ------------------------*/
						$_SESSION['personal_details']['ProspectNumber'] 		= xss_filter($requestJson[2]->ProspectNumber);
						$_SESSION['personal_details']['residencetype'] 			= xss_filter($requestJson[2]->ResidenceType);
						$_SESSION['personal_details']['education']					= xss_filter($requestJson[2]->Education);
						$_SESSION['personal_details']['marritalstatus']			= xss_filter($requestJson[2]->MaritalStatus);
						$_SESSION['personal_details']['loanpurpose']				= xss_filter($requestJson[2]->PurposeofLoan);
						$_SESSION['personal_details']['residencestability']	= xss_filter($requestJson[2]->ResidenceStability);
							/* ---------------From 3rd object of an array ends-------------*/
						/*-----------------CIBIL SESSION STARTS-----------------*/
						// $_SESSION['CIBIL']['cibilResponse'] 					= xss_filter($requestJson[4]->CibilResponse);
						// $_SESSION['CIBIL']['status'] 							= xss_filter($requestJson[4]->Status);
						// $_SESSION['CIBIL']['revised_MaxAmount'] 				= round(xss_filter($requestJson[4]->MaxAmount));
						// $_SESSION['CIBIL']['revised_Tenure'] 					= xss_filter($requestJson[4]->Tenure);
						// $_SESSION['CIBIL']['revised_EMI'] 						= round(xss_filter($requestJson[4]->EMI));
						// $_SESSION['CIBIL']['revised_ProcessingFee'] 			= round(xss_filter($requestJson[4]->ProcessingFee));
						// $_SESSION['CIBIL']['revised_ROI'] 						= xss_filter($requestJson[4]->ROI);
						/*-----------------CIBIL SESSION ENDS--------------------*/

						$_SESSION['co_applicant_details']['companyName'] 									= xss_filter($requestJson[3]->CoCompanyName);
						$_SESSION['co_applicant_details']['otherCompanyName'] 						= xss_filter($requestJson[3]->CoOtherCompanyName);
						$_SESSION['co_applicant_details']['relationType'] 								= xss_filter($requestJson[3]->RelationwithApplicant);
						$_SESSION['co_applicant_details']['monthlySalary']								= xss_filter($requestJson[3]->CoMonthlySalary);
						$_SESSION['co_applicant_details']['currentEmi']										= xss_filter($requestJson[3]->CoMonthlyObligation);
						$_SESSION['co_applicant_details']['applicantname']								= xss_filter($requestJson[3]->CoFName);
						$_SESSION['co_applicant_details']['lastname']											= xss_filter($requestJson[3]->CoLName);
						$_SESSION['co_applicant_details']['middlename']										= xss_filter($requestJson[3]->CoMName);
						$_SESSION['co_applicant_details']['gender']												= xss_filter($requestJson[3]->CoGender);
						$_SESSION['co_applicant_details']['panno']												= xss_filter($requestJson[3]->CoPAN);
						$_SESSION['co_applicant_details']['dob']													= xss_filter($requestJson[3]->CoDOB);
						$_SESSION['co_applicant_details']['mobileno']											= xss_filter($requestJson[3]->CoMobileNo);
						$_SESSION['co_applicant_details']['alternatemobileno']						= xss_filter($requestJson[3]->CoAlternateMobileNo);
						$_SESSION['co_applicant_details']['emailid']											= xss_filter($requestJson[3]->CoPersonalEmailID);
						$_SESSION['co_applicant_details']['permanentaddress1']						= xss_filter($requestJson[3]->CoPermanentAddress1);
						$_SESSION['co_applicant_details']['permanentaddress2']						= xss_filter($requestJson[3]->CoPermanentAddress2);
						$_SESSION['co_applicant_details']['permanentaddress3']						= xss_filter($requestJson[3]->CoPermanentAddress3);
						$_SESSION['co_applicant_details']['permanentpincode']							= xss_filter($requestJson[3]->CoPermanentPin);
						$_SESSION['co_applicant_details']['permanentstate']								= '';
						$_SESSION['co_applicant_details']['permanentcity']								= '';
						$_SESSION['co_applicant_details']['perm_state_code']							= xss_filter($requestJson[3]->CoPermanentState);
						$_SESSION['co_applicant_details']['perm_city_code']								= xss_filter($requestJson[3]->CoPermanentCity);
						$_SESSION['co_applicant_details']['currentaddress1']							= xss_filter($requestJson[3]->CoCurrentAddress1);
						$_SESSION['co_applicant_details']['currentaddress2']							= xss_filter($requestJson[3]->CoCurrentAddress2);
						$_SESSION['co_applicant_details']['currentaddress3']							= xss_filter($requestJson[3]->CoCurrentAddress3);
						$_SESSION['co_applicant_details']['currentpincode']								= xss_filter($requestJson[3]->CoCurrentPin);
						$_SESSION['co_applicant_details']['currentstate']									= '';
						$_SESSION['co_applicant_details']['currentcity']									= '';
						$_SESSION['co_applicant_details']['curr_state_code'] 							= xss_filter($requestJson[3]->CoCurrentState);
						$_SESSION['co_applicant_details']['curr_city_code']  							= xss_filter($requestJson[3]->CoCurrentCity);
						$_SESSION['co_applicant_details']['workexperiance']								= xss_filter($requestJson[3]->CoCurrentWorkExp);
						$_SESSION['co_applicant_details']['totworkexperiance']						= xss_filter($requestJson[3]->CoTotalWorkExp);
						$_SESSION['co_applicant_details']['occupation']										= xss_filter($requestJson[3]->EmploymentType);
						$_SESSION['co_applicant_details']['cnamecoappnature']							= xss_filter($requestJson[3]->NatureOfBusiness);
						$_SESSION['co_applicant_details']['cnamecoappnatureprofession']		= xss_filter($requestJson[3]->Profession);
						$_SESSION['co_applicant_details']['cnamecoappnatureconstitution']	= xss_filter($requestJson[3]->ConstitutionType);
						$_SESSION['co_applicant_details']['CIBIL']['ProcessingFeeActual']	= xss_filter($requestJson[4]->Processingfee);
						$_SESSION['co_applicant_details']['CIBIL']['ROIActual']						= $_SESSION['CIBIL']['revised_ROI']	= xss_filter($requestJson[4]->ROI);
						$_SESSION['co_applicant_details']['CIBIL']['processing_fee'] 			= $_SESSION['CIBIL']['revised_ProcessingFee'] = xss_filter($requestJson[4]->Processingfee);

						echo "page12";
						exit;
					}
					
					if($jsonDecode->PageNumber == '13') {
						//echo '<pre>'; print_r($jsonDecode); echo '</pre>';
						//echo '<pre>'; print_r($requestJson); echo '</pre>';
						//echo '<pre>'; print_r($responseJson); echo '</pre>';
						//exit;
						$_SESSION['doc_uploads'] = '';
						$count = count($requestJson);
						for($i=5; $i<$count; $i++) {
							$_SESSION['doc_uploads'][] = $requestJson[$i];
						}
						/*------------------From 2nd object of the array------------------------*/
						$_SESSION['personal_details']['CRMLeadID']				= xss_filter($requestJson[1]->CRMLeadID);
						$_SESSION['personal_details']['companyname'] 			= xss_filter($requestJson[0]->CompanyName);
						$_SESSION['personal_details']['salary'] 				= xss_filter($requestJson[0]->MonthlySalary);
						$_SESSION['personal_details']['obligation'] 			= xss_filter($requestJson[0]->MonthlyObligation);
						$_SESSION['personal_details']['emailid']				= xss_filter($requestJson[0]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno']				= xss_filter($requestJson[0]->MobileNo);
						$_SESSION['personal_details']['alternatemobileno']		= xss_filter($requestJson[1]->AlternateMobileNo);
						$_SESSION['personal_details']['kycflag'] 				= xss_filter($requestJson[1]->KYCFlag);
						$_SESSION['personal_details']['applicantname']			= xss_filter($requestJson[1]->FName);
						$_SESSION['personal_details']['lastname']				= xss_filter($requestJson[1]->LName);
						$_SESSION['personal_details']['middlename']				= xss_filter($requestJson[1]->MName);
						$_SESSION['personal_details']['gender']					= xss_filter($requestJson[1]->Gender);
						$_SESSION['personal_details']['panno']					= xss_filter($requestJson[1]->PAN);
						$_SESSION['personal_details']['dob']					= xss_filter($requestJson[1]->DOB);
						$_SESSION['personal_details']['permanentaddress1'] 		= xss_filter($requestJson[1]->PermanentAddress1);
						$_SESSION['personal_details']['permanentaddress2'] 		= xss_filter($requestJson[1]->PermanentAddress2);
						$_SESSION['personal_details']['permanentaddress3']		= xss_filter($requestJson[1]->PermanentAddress3);
						$_SESSION['personal_details']['permanentpincode']		= xss_filter($requestJson[1]->PermanentPin);
						$_SESSION['personal_details']['perm_state_code']		= xss_filter($requestJson[1]->PermanentState);
						$_SESSION['personal_details']['perm_city_code']			= xss_filter($requestJson[1]->PermanentCity);
						$_SESSION['personal_details']['currentaddress1']		= xss_filter($requestJson[1]->CurrentAddress1);
						$_SESSION['personal_details']['currentaddress2']		= xss_filter($requestJson[1]->CurrentAddress2);
						$_SESSION['personal_details']['currentaddress3']		= xss_filter($requestJson[1]->CurrentAddress3);
						$_SESSION['personal_details']['currentpincode']			= xss_filter($requestJson[1]->CurrentPin);
						$_SESSION['personal_details']['curr_state_code']		= xss_filter($requestJson[1]->CurrentState);
						$_SESSION['personal_details']['curr_city_code']			= xss_filter($requestJson[1]->CurrentCity);
						$_SESSION['personal_details']['workexperiance']			= xss_filter($requestJson[1]->CurrentWorkExp);
						$_SESSION['personal_details']['totworkexperiance']		= xss_filter($requestJson[1]->TotalWorkExp);
						$_SESSION['personal_details']['emailid'] 				= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno'] 				= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['appliedloanamt'] 		= xss_filter($requestJson[4]->AppliedLoanamount);
						$_SESSION['personal_details']['minloanamt'] 			= 100000;
						$_SESSION['personal_details']['tenure'] 				= xss_filter($requestJson[4]->Tenure);
						$_SESSION['personal_details']['roi_actual'] 			= xss_filter($requestJson[4]->ROI);
						$_SESSION['personal_details']['processing_fee_actual'] 	= xss_filter($requestJson[4]->Processingfee);
						$_SESSION['personal_details']['processing_fee'] 		= xss_filter($requestJson[4]->Processingfee);
						$_SESSION['personal_details']['actualloanEMI'] 			= xss_filter($requestJson[4]->Emi);
						$_SESSION['personal_details']['totalamountpayable'] 	= xss_filter($requestJson[4]->TotalPayableAmount);
						/*------------------From 2nd object of the array Ends------------------------*/
						/* ---------------From 3rd object of an array starts. ------------------------*/
						$_SESSION['personal_details']['ProspectNumber'] 		= xss_filter($requestJson[2]->ProspectNumber);
						$_SESSION['personal_details']['residencetype'] 			= xss_filter($requestJson[2]->ResidenceType);
						$_SESSION['personal_details']['education']				= xss_filter($requestJson[2]->Education);
						$_SESSION['personal_details']['marritalstatus']			= xss_filter($requestJson[2]->MaritalStatus);
						$_SESSION['personal_details']['loanpurpose']			= xss_filter($requestJson[2]->PurposeofLoan);
						$_SESSION['personal_details']['residencestability']		= xss_filter($requestJson[2]->ResidenceStability);
							/* ---------------From 3rd object of an array ends-------------*/
						/*-----------------CIBIL SESSION STARTS-----------------*/
						// $_SESSION['CIBIL']['cibilResponse'] 					= xss_filter($requestJson[4]->CibilResponse);
						// $_SESSION['CIBIL']['status'] 							= xss_filter($requestJson[4]->Status);
						// $_SESSION['CIBIL']['revised_MaxAmount'] 				= round(xss_filter($requestJson[4]->MaxAmount));
						// $_SESSION['CIBIL']['revised_Tenure'] 					= xss_filter($requestJson[4]->Tenure);
						// $_SESSION['CIBIL']['revised_EMI'] 						= round(xss_filter($requestJson[4]->EMI));
						// $_SESSION['CIBIL']['revised_ProcessingFee'] 			= round(xss_filter($requestJson[4]->ProcessingFee));
						// $_SESSION['CIBIL']['revised_ROI'] 						= xss_filter($requestJson[4]->ROI);
						/*-----------------CIBIL SESSION ENDS--------------------*/

						$_SESSION['co_applicant_details']['companyName'] 					= xss_filter($requestJson[3]->CoCompanyName);
						$_SESSION['co_applicant_details']['otherCompanyName'] 				= xss_filter($requestJson[3]->CoOtherCompanyName);
						$_SESSION['co_applicant_details']['relationType'] 					= xss_filter($requestJson[3]->RelationwithApplicant);
						$_SESSION['co_applicant_details']['monthlySalary']					= xss_filter($requestJson[3]->CoMonthlySalary);
						$_SESSION['co_applicant_details']['currentEmi']						= xss_filter($requestJson[3]->CoMonthlyObligation);
						$_SESSION['co_applicant_details']['applicantname']					= xss_filter($requestJson[3]->CoFName);
						$_SESSION['co_applicant_details']['lastname']						= xss_filter($requestJson[3]->CoLName);
						$_SESSION['co_applicant_details']['middlename']						= xss_filter($requestJson[3]->CoMName);
						$_SESSION['co_applicant_details']['gender']							= xss_filter($requestJson[3]->CoGender);
						$_SESSION['co_applicant_details']['panno']							= xss_filter($requestJson[3]->CoPAN);
						$_SESSION['co_applicant_details']['dob']							= xss_filter($requestJson[3]->CoDOB);
						$_SESSION['co_applicant_details']['mobileno']						= xss_filter($requestJson[3]->CoMobileNo);
						$_SESSION['co_applicant_details']['alternatemobileno']				= xss_filter($requestJson[3]->CoAlternateMobileNo);
						$_SESSION['co_applicant_details']['emailid']						= xss_filter($requestJson[3]->CoPersonalEmailID);
						$_SESSION['co_applicant_details']['permanentaddress1']				= xss_filter($requestJson[3]->CoPermanentAddress1);
						$_SESSION['co_applicant_details']['permanentaddress2']				= xss_filter($requestJson[3]->CoPermanentAddress2);
						$_SESSION['co_applicant_details']['permanentaddress3']				= xss_filter($requestJson[3]->CoPermanentAddress3);
						$_SESSION['co_applicant_details']['permanentpincode']				= xss_filter($requestJson[3]->CoPermanentPin);
						$_SESSION['co_applicant_details']['permanentstate']					= '';
						$_SESSION['co_applicant_details']['permanentcity']					= '';
						$_SESSION['co_applicant_details']['perm_state_code']				= xss_filter($requestJson[3]->CoPermanentState);
						$_SESSION['co_applicant_details']['perm_city_code']					= xss_filter($requestJson[3]->CoPermanentCity);
						$_SESSION['co_applicant_details']['currentaddress1']				= xss_filter($requestJson[3]->CoCurrentAddress1);
						$_SESSION['co_applicant_details']['currentaddress2']				= xss_filter($requestJson[3]->CoCurrentAddress2);
						$_SESSION['co_applicant_details']['currentaddress3']				= xss_filter($requestJson[3]->CoCurrentAddress3);
						$_SESSION['co_applicant_details']['currentpincode']					= xss_filter($requestJson[3]->CoCurrentPin);
						$_SESSION['co_applicant_details']['currentstate']					= '';
						$_SESSION['co_applicant_details']['currentcity']					= '';
						$_SESSION['co_applicant_details']['curr_state_code'] 				= xss_filter($requestJson[3]->CoCurrentState);
						$_SESSION['co_applicant_details']['curr_city_code']  				= xss_filter($requestJson[3]->CoCurrentCity);
						$_SESSION['co_applicant_details']['workexperiance']					= xss_filter($requestJson[3]->CoCurrentWorkExp);
						$_SESSION['co_applicant_details']['totworkexperiance']				= xss_filter($requestJson[3]->CoTotalWorkExp);
						$_SESSION['co_applicant_details']['occupation']						= xss_filter($requestJson[3]->EmploymentType);
						$_SESSION['co_applicant_details']['cnamecoappnature']				= xss_filter($requestJson[3]->NatureOfBusiness);
						$_SESSION['co_applicant_details']['cnamecoappnatureprofession']		= xss_filter($requestJson[3]->Profession);
						$_SESSION['co_applicant_details']['cnamecoappnatureconstitution']	= xss_filter($requestJson[3]->ConstitutionType);
						$_SESSION['co_applicant_details']['CIBIL']['ROIActual']	= $_SESSION['CIBIL']['revised_ROI']	= xss_filter($requestJson[4]->ROI);
						$_SESSION['co_applicant_details']['CIBIL']['processing_fee'] = $_SESSION['CIBIL']['revised_ProcessingFee'] = xss_filter($requestJson[4]->Processingfee);
						$_SESSION['co_applicant_details']['CIBIL']['ProcessingFeeActual']	= xss_filter($requestJson[4]->Processingfee);
						echo "page13";
						exit;
					}
					
					if($jsonDecode->PageNumber == '14') {
						//echo '<pre>'; print_r($jsonDecode); echo '</pre>';
						//echo '<pre>'; print_r($requestJson); echo '</pre>';
						//echo '<pre>'; print_r($responseJson); echo '</pre>';
						//exit;
						$_SESSION['doc_uploads'] = '';
						$count = count($requestJson);
						for($i=5; $i<$count; $i++) {
							$_SESSION['doc_uploads'][] = $requestJson[$i];
						}
						/*------------------From 2nd object of the array------------------------*/
						$_SESSION['personal_details']['CRMLeadID']				= xss_filter($requestJson[1]->CRMLeadID);
						$_SESSION['personal_details']['companyname'] 			= xss_filter($requestJson[0]->CompanyName);
						$_SESSION['personal_details']['salary'] 				= xss_filter($requestJson[0]->MonthlySalary);
						$_SESSION['personal_details']['obligation'] 			= xss_filter($requestJson[0]->MonthlyObligation);
						$_SESSION['personal_details']['emailid']				= xss_filter($requestJson[0]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno']				= xss_filter($requestJson[0]->MobileNo);
						$_SESSION['personal_details']['alternatemobileno']		= xss_filter($requestJson[1]->AlternateMobileNo);
						$_SESSION['personal_details']['kycflag'] 				= xss_filter($requestJson[1]->KYCFlag);
						$_SESSION['personal_details']['applicantname']			= xss_filter($requestJson[1]->FName);
						$_SESSION['personal_details']['lastname']				= xss_filter($requestJson[1]->LName);
						$_SESSION['personal_details']['middlename']				= xss_filter($requestJson[1]->MName);
						$_SESSION['personal_details']['gender']					= xss_filter($requestJson[1]->Gender);
						$_SESSION['personal_details']['panno']					= xss_filter($requestJson[1]->PAN);
						$_SESSION['personal_details']['dob']					= xss_filter($requestJson[1]->DOB);
						$_SESSION['personal_details']['permanentaddress1'] 		= xss_filter($requestJson[1]->PermanentAddress1);
						$_SESSION['personal_details']['permanentaddress2'] 		= xss_filter($requestJson[1]->PermanentAddress2);
						$_SESSION['personal_details']['permanentaddress3']		= xss_filter($requestJson[1]->PermanentAddress3);
						$_SESSION['personal_details']['permanentpincode']		= xss_filter($requestJson[1]->PermanentPin);
						$_SESSION['personal_details']['perm_state_code']		= xss_filter($requestJson[1]->PermanentState);
						$_SESSION['personal_details']['perm_city_code']			= xss_filter($requestJson[1]->PermanentCity);
						$_SESSION['personal_details']['currentaddress1']		= xss_filter($requestJson[1]->CurrentAddress1);
						$_SESSION['personal_details']['currentaddress2']		= xss_filter($requestJson[1]->CurrentAddress2);
						$_SESSION['personal_details']['currentaddress3']		= xss_filter($requestJson[1]->CurrentAddress3);
						$_SESSION['personal_details']['currentpincode']			= xss_filter($requestJson[1]->CurrentPin);
						$_SESSION['personal_details']['curr_state_code']		= xss_filter($requestJson[1]->CurrentState);
						$_SESSION['personal_details']['curr_city_code']			= xss_filter($requestJson[1]->CurrentCity);
						$_SESSION['personal_details']['workexperiance']			= xss_filter($requestJson[1]->CurrentWorkExp);
						$_SESSION['personal_details']['totworkexperiance']		= xss_filter($requestJson[1]->TotalWorkExp);
						$_SESSION['personal_details']['emailid'] 				= xss_filter($requestJson[1]->PersonalEmailID);
						$_SESSION['personal_details']['mobileno'] 				= xss_filter($requestJson[1]->MobileNo);
						$_SESSION['personal_details']['appliedloanamt'] 		= xss_filter($requestJson[4]->AppliedLoanamount);
						$_SESSION['personal_details']['minloanamt'] 			= 100000;
						$_SESSION['personal_details']['tenure'] 				= xss_filter($requestJson[4]->Tenure);
						$_SESSION['personal_details']['roi_actual'] 			= xss_filter($requestJson[4]->ROI);
						$_SESSION['personal_details']['processing_fee_actual'] 	= xss_filter($requestJson[4]->Processingfee);
						$_SESSION['personal_details']['processing_fee'] 		= xss_filter($requestJson[4]->Processingfee);
						$_SESSION['personal_details']['actualloanEMI'] 			= xss_filter($requestJson[4]->Emi);
						$_SESSION['personal_details']['totalamountpayable'] 	= xss_filter($requestJson[4]->TotalPayableAmount);
						/*------------------From 2nd object of the array Ends------------------------*/
						/* ---------------From 3rd object of an array starts. ------------------------*/
						$_SESSION['personal_details']['ProspectNumber'] 		= xss_filter($requestJson[2]->ProspectNumber);
						$_SESSION['personal_details']['residencetype'] 			= xss_filter($requestJson[2]->ResidenceType);
						$_SESSION['personal_details']['education']				= xss_filter($requestJson[2]->Education);
						$_SESSION['personal_details']['marritalstatus']			= xss_filter($requestJson[2]->MaritalStatus);
						$_SESSION['personal_details']['loanpurpose']			= xss_filter($requestJson[2]->PurposeofLoan);
						$_SESSION['personal_details']['residencestability']		= xss_filter($requestJson[2]->ResidenceStability);
							/* ---------------From 3rd object of an array ends-------------*/
						/*-----------------CIBIL SESSION STARTS-----------------*/
						// $_SESSION['CIBIL']['cibilResponse'] 					= xss_filter($requestJson[4]->CibilResponse);
						// $_SESSION['CIBIL']['status'] 							= xss_filter($requestJson[4]->Status);
						// $_SESSION['CIBIL']['revised_MaxAmount'] 				= round(xss_filter($requestJson[4]->MaxAmount));
						// $_SESSION['CIBIL']['revised_Tenure'] 					= xss_filter($requestJson[4]->Tenure);
						// $_SESSION['CIBIL']['revised_EMI'] 						= round(xss_filter($requestJson[4]->EMI));
						// $_SESSION['CIBIL']['revised_ProcessingFee'] 			= round(xss_filter($requestJson[4]->ProcessingFee));
						// $_SESSION['CIBIL']['revised_ROI'] 						= xss_filter($requestJson[4]->ROI);
						/*-----------------CIBIL SESSION ENDS--------------------*/

						$_SESSION['co_applicant_details']['companyName'] 					= xss_filter($requestJson[3]->CoCompanyName);
						$_SESSION['co_applicant_details']['otherCompanyName'] 				= xss_filter($requestJson[3]->CoOtherCompanyName);
						$_SESSION['co_applicant_details']['relationType'] 					= xss_filter($requestJson[3]->RelationwithApplicant);
						$_SESSION['co_applicant_details']['monthlySalary']					= xss_filter($requestJson[3]->CoMonthlySalary);
						$_SESSION['co_applicant_details']['currentEmi']						= xss_filter($requestJson[3]->CoMonthlyObligation);
						$_SESSION['co_applicant_details']['applicantname']					= xss_filter($requestJson[3]->CoFName);
						$_SESSION['co_applicant_details']['lastname']						= xss_filter($requestJson[3]->CoLName);
						$_SESSION['co_applicant_details']['middlename']						= xss_filter($requestJson[3]->CoMName);
						$_SESSION['co_applicant_details']['gender']							= xss_filter($requestJson[3]->CoGender);
						$_SESSION['co_applicant_details']['panno']							= xss_filter($requestJson[3]->CoPAN);
						$_SESSION['co_applicant_details']['dob']							= xss_filter($requestJson[3]->CoDOB);
						$_SESSION['co_applicant_details']['mobileno']						= xss_filter($requestJson[3]->CoMobileNo);
						$_SESSION['co_applicant_details']['alternatemobileno']				= xss_filter($requestJson[3]->CoAlternateMobileNo);
						$_SESSION['co_applicant_details']['emailid']						= xss_filter($requestJson[3]->CoPersonalEmailID);
						$_SESSION['co_applicant_details']['permanentaddress1']				= xss_filter($requestJson[3]->CoPermanentAddress1);
						$_SESSION['co_applicant_details']['permanentaddress2']				= xss_filter($requestJson[3]->CoPermanentAddress2);
						$_SESSION['co_applicant_details']['permanentaddress3']				= xss_filter($requestJson[3]->CoPermanentAddress3);
						$_SESSION['co_applicant_details']['permanentpincode']				= xss_filter($requestJson[3]->CoPermanentPin);
						$_SESSION['co_applicant_details']['permanentstate']					= '';
						$_SESSION['co_applicant_details']['permanentcity']					= '';
						$_SESSION['co_applicant_details']['perm_state_code']				= xss_filter($requestJson[3]->CoPermanentState);
						$_SESSION['co_applicant_details']['perm_city_code']					= xss_filter($requestJson[3]->CoPermanentCity);
						$_SESSION['co_applicant_details']['currentaddress1']				= xss_filter($requestJson[3]->CoCurrentAddress1);
						$_SESSION['co_applicant_details']['currentaddress2']				= xss_filter($requestJson[3]->CoCurrentAddress2);
						$_SESSION['co_applicant_details']['currentaddress3']				= xss_filter($requestJson[3]->CoCurrentAddress3);
						$_SESSION['co_applicant_details']['currentpincode']					= xss_filter($requestJson[3]->CoCurrentPin);
						$_SESSION['co_applicant_details']['currentstate']					= '';
						$_SESSION['co_applicant_details']['currentcity']					= '';
						$_SESSION['co_applicant_details']['curr_state_code'] 				= xss_filter($requestJson[3]->CoCurrentState);
						$_SESSION['co_applicant_details']['curr_city_code']  				= xss_filter($requestJson[3]->CoCurrentCity);
						$_SESSION['co_applicant_details']['workexperiance']					= xss_filter($requestJson[3]->CoCurrentWorkExp);
						$_SESSION['co_applicant_details']['totworkexperiance']				= xss_filter($requestJson[3]->CoTotalWorkExp);
						$_SESSION['co_applicant_details']['occupation']						= xss_filter($requestJson[3]->EmploymentType);
						$_SESSION['co_applicant_details']['cnamecoappnature']				= xss_filter($requestJson[3]->NatureOfBusiness);
						$_SESSION['co_applicant_details']['cnamecoappnatureprofession']		= xss_filter($requestJson[3]->Profession);
						$_SESSION['co_applicant_details']['cnamecoappnatureconstitution']	= xss_filter($requestJson[3]->ConstitutionType);
						$_SESSION['co_applicant_details']['CIBIL']['ROIActual']	= $_SESSION['CIBIL']['revised_ROI']	= xss_filter($requestJson[4]->ROI);
						$_SESSION['co_applicant_details']['CIBIL']['processing_fee'] = $_SESSION['CIBIL']['revised_ProcessingFee'] = xss_filter($requestJson[4]->Processingfee);

						echo "page14";
						exit;
					}
				}
				echo $curl_response; exit();
			} else {
				echo 0;
				exit();
			}
		}
	} else {
		echo 2;
	}
	echo $crmLeadIdType;
?>