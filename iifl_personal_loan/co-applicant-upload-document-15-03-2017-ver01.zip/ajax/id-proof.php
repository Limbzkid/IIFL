<?php
	session_start();

	//$_SESSION['uploads']['idproof']['filename'] = $dir.$name;
	//$_SESSION['uploads']['idproof']['tempname'] = $temp_name;
	print_r($_SESSION);
	
	echo json_encode('TATATATATATATA');

?>
