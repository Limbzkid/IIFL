<?php
	session_start();
	$_SESSION['ifsc']['code'] 					= $_POST['ifsc'];
	$_SESSION['ifsc']['account_number'] = $_POST['acct_no'];
	$_SESSION['ifsc']['branch'] 				= $_POST['branch'];
	$_SESSION['ifsc']['bank'] 					= $_POST['bank'];
?>
