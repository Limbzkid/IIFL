function isNumberKey(e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57))	{
		return false;
	}
}
$(document).ready(function(){
	var flag = true;
	$('.inputbox input').focus(function(){
		$(this).parent(".input").find('span').addClass("blurtext");
	});
	$('.inputbox input').blur(function(){
		console.log($(this).val());
		if($(this).val().length > 0){
			$(this).parent().find('span').addClass("blurtext");
			$(this).parent().find('.error-user').hide();
			flag = true;
		}else{
			$(this).parent().find('span').removeClass("blurtext");
			$(this).parent().find('.error-user').show();
			flag = false;
		}		
	});

	$('.inputbox input').keyup(function() {
		console.log($(this).attr('data-name'), $(this).val().length);
		//$(this).parent().find('.error-user').hide();
		if($(this).val().length > 0){
			$(this).parent().find('span').addClass("notext");
			if($(this).attr('data-name') == 'adhar' && $(this).val().length == 12){
				flag = true;
				$(this).parent().find('.error-user').hide();
				//$(this).prop('disabled', true);
			}else{
				flag = false;
				$(this).parent().find('.error-user').show();
			}
		}else{
			$(this).parent().find('span').removeClass("notext");
		}
		console.log(flag);
		if(flag){
			$('#aadharNoslot').prop('disabled', false);
		}else{
			$('#aadharNoslot').prop('disabled', true);
		}
	});

	$("#noAadharSbmit1").click(function(){
		$('.aadharblock').hide();
		$('.data_block1').fadeIn();
	});

	$('.data_block1 .inputbox input:first').blur(function(){
		$('.data_block2').fadeIn();
		$(window).scrollTop($(this).offset().top);
	});

	$('.data_block2 .inputbox input:first').blur(function(){
		$('.data_block3').fadeIn();
		$(window).scrollTop($(this).offset().top);
	});

	$('.data_block3 .inputbox input:first').blur(function(){
		$('.next-home').fadeIn();
		$(window).scrollTop($(this).offset().top);
	});

  /**/$("#aadharNoslot").click(function(){
		alert("dfgdf");
		$('.enterotpsection').fadeIn();
	  });



















/*var input = document.getElementsByName('age')[0]
var errorHolder = document.getElementById('error')
input.onfocus = function() {
 this.style.backgroundColor = ''
 errorHolder.innerHTML = ''
}
input.onblur = function() {
 var age = +this.value
 if (isNaN(age)) {
  this.style.backgroundColor = 'red'
  errorHolder.innerHTML = 'Enter a number please.'
}
}*/
});