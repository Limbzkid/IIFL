<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1,  user-scalable = no" />
<title>IIFL</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/media.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/jquery.2.1.4.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
</head>
<body style="font-family:'MyriadPro-Semibold';">
<div id="main-wrap">
  <header>
    <div class="header-inner">
      <div class="logo"><img src="images/logo.jpg" class="scale"></div>
      <div class="personal-loan"><img src="images/personal.png" class="scale"></div>
      <div class="clr"></div>
      <div class="continue-journey-link"><a href="continue-your-journey.php">Resume your previously saved form</a></div>
      <div class="card-container-outerinner">
        <div class="pendulamline-inner"><img src="images/pendulamline.jpg" class="scale"></div>
        <div class="card-container1 effect__random card-container" data-id="1">
          <div class="card__front"> <img src="images/48hours.png" class="scale">
            <p class="pendulamtxt">Express<br>
              Personal<br>
              Loan</p>
          </div>
          <div class="card__back"><img src="images/48hours.png" class="scale">
            <p class="pendulamtxt">DISBURSAL<br>
              IN<br>
              8 HOURS* <br/>
              <small> T&C Apply</small></p>
          </div>
        </div>
      </div>
    </div>
  </header>
  <div class="clear"></div>
  <section class="body-home-outer myclass">
    <div class="innerbody-home-affiliate">
      <div class="data_block1">
        <div class="aadhar-heading">Tell us a bit about yourself</div>
        <div class="inputbox">
          <label class="input">
          <span>First Name*</span>
          <input type="text" name="applicantname" id="applicantname" maxlength="20" value="" />
          <div id="error-user">Please enter first name</div>
          </label>
        </div>
        <div class="inputbox">
          <label class="input">
          <span>Middle Name</span>
          <input type="text" name="middlename" id="middlename" maxlength="20" value="" />
          <div id="error-user">Please enter middle name</div>
          </label>
        </div>
        <div class="inputbox">
          <label class="input"> <span>Last Name*</span>
			<input type="text" name="lastname" id="lastname" maxlength="20" value="" />
			<div id="error-user">Please enter last name</div>
		 </label>
        </div>
        <div class="inputbox">
         <label class="input"> <span>PAN Card Number*</span>
			<input type="text" name="panno" id="panno" class="pannumber" maxlength="10" value=""/>
			<div id="error-user">Please enter pan card number</div>
		</label>
        </div>
        <div class="inputbox dob">
          <input name="dob" type="text" class="inputdob" value="Date of birth" >
			<div id="error-user">Please enter date of birth</div>
			<div class="clear"></div>
			<span class=note>(Minimum age 25 years old)</span>
        </div>
        <div class="aadhar-heading">Where can we reach you?</div>
        <div class="inputbox">
          <label class="input">
          <span>Mobile number 1*</span>
          <input type="text" name="applicantname" id="applicantname" maxlength="20" value="" />
          <div id="error-user">Please enter mobile number</div>
          </label>
        </div>
        <div class="inputbox">
          <label class="input">
          <span>Middle Name</span>
          <input type="text" name="middlename" id="middlename" maxlength="20" value="" />
          <div id="error-user">Please enter middle name</div>
          </label>
        </div>
        <div class="inputbox">
          <label class="input"> <span>Last Name*</span>
			<input type="text" name="lastname" id="lastname" maxlength="20" value="" />
			<div id="error-user">Please enter last name</div>
		 </label>
        </div>
        





        <div class="clear"></div>       
      </div>
      <div class="data_block2">222</div>
    </div>
  </section>
</div>
<script src="js/cards.js" type="text/javascript"></script>
</body>
</html>